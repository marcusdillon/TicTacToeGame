Assignment 2
ITI 1121 - Section A
Student: Marcus Dillon
Student #: 300113181
Team: Worked Alone

Description: This assignment consisted of building on top of the previous assignment by adding a bot to play TicTacToe against. This bot
chooses random positions on the board. 