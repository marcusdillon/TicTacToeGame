//Student 1 name: Marcus Dillon
//Student 2 name: Marcus Dillon

/**
 * An enum class that defines the
 * values <b>PLAYING</b>, <b>DRAW</b>,
 * <b>XWIN</b> and <b>OWIN</b>
 *
 * 
 */

public enum GameState {
	PLAYING,
    DRAW,
    XWIN,
    OWIN
}