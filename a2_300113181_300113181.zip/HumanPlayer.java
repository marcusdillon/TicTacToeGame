//Student 1 name: Marcus Dillon
//Student 2 name: Marcus Dillon
/**
 * The class <b>HumanPlayer</b> is the class that controls the human's plays.
 * 
 * 
 */
import java.io.Console;

public class HumanPlayer implements Player {
	// read a position to play from the console and call 
	// game.play(position): if the level was advanced after the call, then finish,
    // otherwise repeat and get another position

    private HumanPlayer person;
    Console console = System.console();
    
    /**
    * Constructor for the class HumanPlayer
    * <p>
    * @author Marcus Dillon
    * @param  void
    * @return void
    */
    public void HumanPlayer() {
        HumanPlayer person = new HumanPlayer();
    }

    /**
    * This method queries the user for input and plays at the corresponding location. It also
    * handles exceptions such as inputing a number out of bounds of trying to play a non-empty cell.
    * <p>
    * @author Marcus Dillon
    * @param  board  reference to a TicTacToe Game which is being played
    * @return void
    */
    public void Play(TicTacToeGame board) {
        int pass = 0;

        while (pass==0) {
            if (board.getGameState() == GameState.PLAYING) {
                String answer = console.readLine();
                int value;
                value = Integer.parseInt(answer)-1;

                if (value < 0 || value >= (board.getLines()*board.getColumns() )) {
                    System.out.println("The value should be between 1 and " + (board.getLines() * board.getColumns()));
                    System.out.println(board);
                    if (board.nextCellValue() == CellValue.X) {
                        System.out.println(CellValue.X + " to play: "  );
                    } else {
                        System.out.println(CellValue.O + " to play: "  );
                    }

                } else if (board.valueAt(value) != CellValue.EMPTY) {
                    System.out.println("This value has already been played");
                    System.out.println(board);
                    if (board.nextCellValue() == CellValue.X) {
                        System.out.println(CellValue.X + " to play: "  );
                    } else {
                        System.out.println(CellValue.O + " to play: "  );
                    }

                } else {
                    board.play(value);
                    pass =1;
                }

            }else {
                System.out.println("This game is over!");
                pass =1;
            }
        }
    }

   
}

