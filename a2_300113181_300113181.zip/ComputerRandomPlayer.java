//Student 1 name: Marcus Dillon
//Student 2 name: Marcus Dillon

/**
 * The class <b>ComputerRandomPlayer</b> is the class that controls the computer's plays.
 * 
 * 
 */

import java.util.*;

public class ComputerRandomPlayer implements Player {
	//generate random position at an empty cell!!
	//call game.play(position)

    /**
    * Returns an Image object that can then be painted on the screen. 
    * The url argument must specify an absolute <a href="#{@link}">{@link URL}</a>. The name
    * argument is a specifier that is relative to the url argument. 
    * <p>
    * This method always returns immediately, whether or not the 
    * image exists. When this applet attempts to draw the image on
    * the screen, the data will be loaded. The graphics primitives 
    * that draw the image will incrementally paint on the screen. 
    *
    * @param  url  an absolute URL giving the base location of the image
    * @param  name the location of the image, relative to the url argument
    * @return      the image at the specified URL
    * @see         Image
    */

    public int getNumberEmpty(TicTacToeGame board) { 
        int count = 0;
        for (int i=0; i < (board.getColumns() * board.getLines()); i++ ) {
            if (board.valueAt(i) == CellValue.EMPTY) {
                count++;
            }
        }
        return count;
    }

    public int [] getEmptyArray(TicTacToeGame board) {
        int [] ret = new int [getNumberEmpty(board)];
        int count = 0;

        for (int i=0; i < (board.getColumns() * board.getLines()); i++ ) {
            if (board.valueAt(i) == CellValue.EMPTY) {
                ret[count] = i;
                count++;
            }
        }

        return ret;
    }

    public double[] fillProbabilitiesArray (double increments, int emptyNum) {
        double [] temp = new double [emptyNum];
        double nextIncrement = increments;

        for (int i=0; i < emptyNum; i++) {
            temp[i] = nextIncrement;
            nextIncrement = nextIncrement + increments;
        }
        return temp;

    }

    public void Play (TicTacToeGame board) {
        int playIndex=0;
        int emptyNum = getNumberEmpty(board);
        double numer = 1;
        double increments = numer/emptyNum;
        double randNum = Utils.generator.nextDouble(1);
        double [] probabilities = new double [emptyNum];
        int [] indexProbabilities = new int [emptyNum];

        indexProbabilities = getEmptyArray(board);
        probabilities = fillProbabilitiesArray(increments, emptyNum);


        for (int i =0; i < emptyNum; i++) { 
            if (randNum < probabilities[i]) {
                playIndex = indexProbabilities[i];
                break;
            }
        }

        if (board.getGameState() == GameState.PLAYING) {
            board.play(playIndex);
            System.out.println(board);
        } else {
            System.out.println("The game is over!");
        }
    }









}

