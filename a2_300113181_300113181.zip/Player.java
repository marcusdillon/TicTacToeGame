//Student 1 name: Marcus Dillon
//Student 2 name: Marcus Dillon
// Create an interface player which defines only one method, the method play.
// Play is void and has one input parameter, a reference to a TicTacToeGame

public interface Player {
	public void Play (TicTacToeGame board);
}