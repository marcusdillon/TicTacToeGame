//Student 1 name: Marcus Dillon
//Student 2 name: Marcus Dillon

/**
 * An enum class that defines the
 * values <b>Empty</b>, <b>X</b>
 * and <b>O</b>.
 *
 * 
 */

public enum CellValue {
    EMPTY,
    X,
    O
}