//Student 1 name: Marcus Dillon
//Student 2 name: Marcus Dillon
import java.io.Console;

/**
 * The class <b>TicTacToe</b> is the class that implements the actual Tic Tac
 * Toe game, where it
 * controls the human and computer activity and prints the result of the game at
 * the end. It also
 * asks the player if he/she wants to continue playing once this game is over.
 * 
 * 
 */

public class TicTacToe {

    /**
     * <b>main</b> of the application. Creates the instance of GameController
     * and starts the game. If two parameters line and column
     * are passed, they are used.
     * Otherwise, a default value is used. Defaults values are also
     * used if the paramters are too small (less than 2).
     * 
     * @param args
     *             command line parameters
     */
    public static void main(String[] args) {
        StudentInfo.display();
        int roundGames = 1;
        Console console = System.console();
        
        //default values used if args are not there:
        int lines = 3;
        int columns = 3;
        int win = 3;

        //change lines, columns and win based on the args values
        if (args.length >= 2) {
            lines = Integer.parseInt(args[0]);
            if(lines<2){
                System.out.println("Invalid argument, using default...");
                lines = 3;
            }
            columns = Integer.parseInt(args[1]);
            if(columns<2){
                System.out.println("Invalid argument, using default...");
                columns = 3;
            }
        }

        if (args.length == 3){
            win = Integer.parseInt(args[2]); //for simplcity, we will only consider the case of 3 cells to win
            if (win < 2) {
                System.out.println("Invalid arguments, using default...");
                win = 3; 
            }       
        } 

        //define an array (say p) of two players (use interface playe for the refernce)
        Player [] players = new Player [2];


        // The first playe is an object of type HumanPlayer and 
        HumanPlayer playerOne = new HumanPlayer();
        players[0] = playerOne;


        // the second player is an object of type  ComputerRandomPlayer()
        ComputerRandomPlayer playerTwo = new ComputerRandomPlayer();
        players[1] = playerTwo;


        //choose player randomly (p[0] or p[1]) 
        Player firstPlayer;
        int storeFirstGamePlayer = 0;
        int firstPlayerLastGame = 0;
        double randNumber = Utils.generator.nextDouble(1);
        int xOrOTracker = 0;
        // Tracks whos turn it is, pair = player 1, odd = player 2
        int playerTurnTracker = 0;

        if (randNumber <= 0.5) {
            firstPlayer = players[0];
            storeFirstGamePlayer = 1;
        } else {
            firstPlayer = players[1];
            storeFirstGamePlayer = 2;
            playerTurnTracker = 1;
            firstPlayerLastGame = 1;
        }

        // create a refernce to an object of type TicTacToeGame
        TicTacToeGame game;
        
        // loop until the input is not 'y' 
        do {
             // create object for TicTacToeGame
            game = new TicTacToeGame(lines,columns,win);
            roundGames++;
            xOrOTracker=0;

            //Me: if we are in round one, we don't need to call Y/N
            if (roundGames == 1) {
                //First round, Human got chosen first
                while (game.getGameState() == GameState.PLAYING) {

                    if (playerTurnTracker % 2 == 0) {
                        System.out.println("Player 1's turn."  );
                        System.out.println(game);
                        if (xOrOTracker % 2 == 0) {
                            System.out.println(CellValue.X + " to play: "  );
                        } else {
                            System.out.println(CellValue.O + " to play: "  );
                        }
                        players[0].Play(game);
                        xOrOTracker++;
                        playerTurnTracker ++;
                    } else {
                        System.out.println("Player 2's turn."  );
                        players[1].Play(game);
                        xOrOTracker++;
                        playerTurnTracker ++;
                    }

                }
                firstPlayerLastGame++;
                System.out.println(game);
                System.out.println("Result: " + game.getGameState());
                System.out.println("Do you want to play again? (y/n)");

            } else {

                if (firstPlayerLastGame % 2 ==0) {
                    playerTurnTracker = 0;
                } else {
                    playerTurnTracker = 1;
                }
                
                while (game.getGameState() == GameState.PLAYING) {

                    if (playerTurnTracker % 2 == 0) {
                        System.out.println("Player 1's turn."  );
                        System.out.println(game);
                        if (xOrOTracker % 2 == 0) {
                            System.out.println(CellValue.X + " to play: "  );
                        } else {
                            System.out.println(CellValue.O + " to play: "  );
                        }
                        players[0].Play(game);
                        xOrOTracker++;
                        playerTurnTracker ++;

                    } else {
                        System.out.println("Player 2's turn."  );
                        players[1].Play(game);
                        xOrOTracker++;
                        playerTurnTracker ++;
                    }

                }
                firstPlayerLastGame++;
                System.out.println(game);
                System.out.println("Result: " + game.getGameState());
                System.out.println("Do you want to play again? (y/n)");
            }
             // for loop that prints who's turn it is, the board, and who is to play, until
                // the game ends
             // prints result of game and ask if you want to play again
        }while(Utils.console.readLine().compareToIgnoreCase("y") == 0);
    }
}
