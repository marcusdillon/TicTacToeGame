//Student 1 name: Marcus Dillon
//Student 2 name: Marcus Dillon
/**
 * The class <b>TicTacToeGame</b> is the class that implements the Tic Tac Toe
 * Game. It contains the grid and tracks its progress. It automatically maintain
 * the current state of the game as players are making moves.
 *
 * 
 */
public class TicTacToeGame {
	/**
	 * The board of the game, stored as a one dimension array.
	 */
	private CellValue[] board;
	private CellValue[][] board2d;

	/**
	 * level records the number of rounds that have been played so far.
	 */
	private int level;

	/**
	 * gameState records the current state of the game
	 */
	private GameState gameState;

	/**
	 * lines is the number of lines in the grid
	 */
	private int lines;

	/**
	 * columns is the number of columns in the grid
	 */
	private int columns;

	/**
	 * sizeWin is the number of cell of the same type that must be aligned to win
	 * the game
	 */
	private int sizeWin;

	/**
	 * default constructor, for a game of 3x3, which must align 3 cells
	 */
	public TicTacToeGame() {
		// Your Code Here
		this(3,3,3);
	}

	/**
	 * constructor allowing to specify the number of lines and the number of columns
	 * for the game. 3 cells must be aligned.
	 * 
	 * @param lines   the number of lines in the game
	 * @param columns the number of columns in the game
	 */
	public TicTacToeGame(int lines, int columns) {
		//your Code Here
		this(lines, columns, 3);
	}

	/**
	 * constructor allowing to specify the number of lines and the number of columns
	 * for the game, as well as the number of cells that must be aligned to win.
	 * 
	 * @param lines   the number of lines in the game
	 * @param columns the number of columns in the game
	 * @param sizeWin the number of cells that must be aligned to win.
	 */
	public TicTacToeGame(int lines, int columns, int sizeWin) {
		// Your Code Here
		this.lines = lines;
		this.columns = columns;
		this.sizeWin = sizeWin;
		board = new CellValue[lines*columns];

		for (int i = 0; i < lines*columns; i++) {
			board[i] = CellValue.EMPTY;
		}
		level = 0;
		this.gameState = GameState.PLAYING;
				 
	}

	/**
	 * getter for the variable lines
	 * 
	 * @return the value of lines
	 */
	public int getLines() {
		// Your Code Here
		return lines; 
	}

	/**
	 * getter for the variable columns
	 * 
	 * @return the value of columns
	 */
	public int getColumns() {
		// Your Code Here
		return columns;
	}

	/**
	 * getter for the variable level
	 * 
	 * @return the value of level
	 */
	public int getLevel() {
		// Your Code Here
		return level;
	}

	/**
	 * getter for the variable sizeWin
	 * 
	 * @return the value of sizeWin
	 */
	public int getSizeWin() {
		// Your Code Here
		return this.sizeWin;
	}

	/**
	 * getter for the variable gameState
	 * 
	 * @return the value of gameState
	 */
	public GameState getGameState() {
		// Your Code Here
		return this.gameState;
	}

	/**
	 * returns the cellValue that is expected next, in other word, which player (X
	 * or O) should play next. This method does not modify the state of the game.
	 * 
	 * @return the value of the enum CellValue corresponding to the next expected
	 *         value.
	 */
	public CellValue nextCellValue() {
		// Your Code Here
		return (level % 2 ==0) ? CellValue.X : CellValue.O;
	}

	/**
	 * returns the value of the cell at index i. If the index is invalid, an error
	 * message is printed out. The behavior is then unspecified
	 * 
	 * @param i the index of the cell in the array board
	 * @return the value at index i in the variable board.
	 */
	public CellValue valueAt(int i) {
		// Your Code Here
		int x = i; 
		return board[x];
	}

   /**
	* This method is called by the next player to play at the cell  at index i.
	* If the index is invalid, an error message is printed out. The behaviour is then unspecified
	* If the chosen cell is not empty, an error message is printed out. The behaviour is then unspecified
	* If the move is valide, the board is updated, as well as the state of the game.
	* To faciliate testing, it is acceptable to keep playing after a game is already won. 
	* If that is the case, the a message should be printed out and the move recorded. 
	* The winner of the game is the player who won first
   	* @param i
    *  the index of the cell in the array board that has been selected by the next player
  	*/
	public void play(int i) {

		// your code here
		//check for invalid values or non-empty cells and print the corrosponding msg
		// otherwise, place x or o in the index i, then
		//if the game state is still PLAYING, then check if the current move change the state 
		if (valueAt(i) != CellValue.EMPTY) 
			System.out.println("CellValue not empty: " + i);
		else {
			board[i] = nextCellValue();
			level ++;
			if (gameState == GameState.PLAYING) {
				setGameState(i);
			}
		}

	}


   /**
	* A helper method which updates the gameState variable
	* correctly after the cell at index i was just set.
	* The method assumes that prior to setting the cell
	* at index i, the gameState variable was correctly set.
	* it also assumes that it is only called if the game was
	* not already finished when the cell at index i was played
	* (the the game was playing). Therefore, it only needs to
	* check if playing at index i has concluded the game
	****************************** 
	*So check if the required number of sizeWin cells are formed to win.
	******************************
    *  the index of the cell in the array board that has just
    * been set
  	*/

	private void setGameState(int index){
		// your code here
		board2d = new CellValue[lines][columns];

		for (int i=0; i < lines; i++) 
			for (int j = 0; j < columns; j++) 
				board2d[i][j] = board[i * columns + j];
	
		for (int i = 0; i < lines; i++) {
			for (int j = 0; j < columns; j++) {
				if (board2d[i][j] != CellValue.EMPTY) {
					checkWinner1 (i,j,true);   // row
					checkWinner1 (i,j,false);  // column
					checkWinner2 (i,j,true);	// main diagonal
					checkWinner2 (i,j,false);	// secondary diagonal
				}
			}
		}

		if (! (gameState == GameState.XWIN || gameState == GameState.OWIN)){
			if (level == lines*columns) {
				gameState = GameState.DRAW;
			}
		}
		

	}

	final String NEW_LINE = System.getProperty("line.separator");
	// returns the OS dependent line separator

   /**
	* Returns a String representation of the game matching
	* the example provided in the assignment's description
	*
   	* @return
    *  String representation of the game
  	*/

	public String toString(){
		// your code here
		// use NEW_LINE defined above rather than \n
		String temp = "";
		String line = "";
		int lineCounter = 0;
		int counter = 0;
		lineCounter = 3*this.lines + this.lines-2;

		for (int x = 0; x <= lineCounter; x++) {
			line = line + "-";
		}

		for (int i =0; i < (this.columns * this.lines); i++) {

			if (counter !=0 && counter != this.lines) {
				temp = temp + " | ";
			}

			if (counter == 0) {
				temp = temp + " ";
			}

			if (counter == this.lines) {
				temp = temp + NEW_LINE + line + NEW_LINE + " ";

				if (board[i] == CellValue.EMPTY) {
					temp = temp + "-";
					counter = 0;
				}

				else {
					temp = temp + board[i];
					counter = 0;
				}
			}

			else {
				if (board[i] == CellValue.EMPTY) {
				temp = temp + "-";
				} else {
				temp = temp + board[i];
				}
			}
			counter++;
		}

		return temp;

	}

	/**
    * This method checks a given cell vertically and horizontally to see if the last play
    * created a win for the player
    * <p>
    * @author Marcus Dillon
    * @param  row  row index of the cell we are checking
    * @param  col  col index of the cell we are checking
    * @param  isRow used to check Vertically and Horizontally 
    * @return void
    */
	void checkWinner1 (int row, int col, boolean isRow) {
		boolean winner = false;
		int winSize = this.sizeWin;
		int count =0;
		// New Code
		if (isRow) {
			if (col + sizeWin <= columns) {
				for (int i =0; i < sizeWin; i++) {
					if (board2d[row][col] == board2d[row][col+i]) {
						count++;
					}
				}
				if (count == sizeWin) 
					winner = true;
			}	
		} else {
			if (row + sizeWin <= lines) {
				for (int i =0; i < sizeWin; i++) {
					if (board2d[row][col] == board2d[row+i][col])
						count++;
				}
				if (count == sizeWin) 
					winner = true;
			}
		}

		if (winner) {
			if (board[row*columns + col] == CellValue.X) gameState = GameState.XWIN;
			else if (board[row * columns + col] == CellValue.O) gameState = GameState.OWIN;
		}
	}

	/**
    * This method checks a given cell diagonally in both directions to see if the last play
    * created a win for the player
    * <p>
    * @author Marcus Dillon
    * @param  row  row index of the cell we are checking
    * @param  col  col index of the cell we are checking
    * @param  isMain used to check Main Diag and Cross Diag
    * @return void
    */
	void checkWinner2 (int row, int col, boolean isMain) {
		boolean winner = false;
		int count = 0;
	
		// New Code
		if (isMain) { // Main Diag
			if (col + sizeWin<= columns && row + sizeWin  <= lines) {
				for (int i =0; i < sizeWin; i++) {
					//System.out.println("i: " + i);
					if (board2d[row][col] == board2d[row+i][col+i]) {
						count++;
					}
				}
				if (count == sizeWin) 
					winner = true;
			}
		} else { // Second Diag 
			if (row + sizeWin <= lines) {
				if (col - sizeWin + 1 >= 0) {
					for (int i =0; i < sizeWin; i++) {
						if (board2d[row][col] == board2d[row+i][col-i]) {
							count++;
						}
					}

					if (count == sizeWin)
						winner = true;
				}
			}
		}
		if (winner) {
			if (board[row*columns + col] == CellValue.X) gameState = GameState.XWIN;
			else if (board[row * columns + col] == CellValue.O) gameState = GameState.OWIN;
		}
	}

}
	
	
	                            

	